<?php
header('Content-Type: text/html; charset=utf-8');
function validateRegistration($data) {
    $errors = [];

    // 用户名验证
    $username = $data['username'] ?? '';
    if (!preg_match('/^[a-zA-Z]\w{2,19}$/', $username)) {
        $errors[] = '用户名：3-20位，字母开头，只允许字母数字下划线';
    }

    // 密码验证（使用之前写的函数）
    if (!isStrongPassword($data['password'] ?? '')) {
        $errors[] = '密码：8-20位，必须包含大小写字母和数字';
    }

    // 邮箱验证
    $email = $data['email'] ?? '';
    if (!preg_match('/^[\w.-]+@[\w.-]+\.\w+$/', $email)) {
        $errors[] = '邮箱格式不正确';
    }

    // 手机号验证
    $phone = $data['phone'] ?? '';
    if (!preg_match('/^1[3-9]\d{9}$/', $phone)) {
        $errors[] = '手机号格式不正确';
    }

    // 年龄验证
    $age = $data['age'] ?? 0;
    if ($age < 18 || $age > 60) {
        $errors[] = '年龄必须在18-60岁之间';
    }

    return [
        'success' => empty($errors),
        'errors' => $errors
    ];
}

// 测试
$test = [
    'username' => 'user123',
    'password' => 'Hello123',
    'email' => 'test@example.com',
    'phone' => '13800138000',
    'age' => 25
];
$result = validateRegistration($test);
var_dump($result);
?>
