<?php
header('Content-Type: text/html; charset=utf-8');
// 检查是否是表单提交
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('请通过表单提交数据');
}

// 获取数据（带默认值）
$name = $_POST['student_name'] ?? '';
$chinese = $_POST['chinese'] ?? 0;
$math = $_POST['math'] ?? 0;
$english = $_POST['english'] ?? 0;

// 验证必填项
if (empty($name)) {
    die('姓名不能为空');
}

// 计算并显示...
?>
