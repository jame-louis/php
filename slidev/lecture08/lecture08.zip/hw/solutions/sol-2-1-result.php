<?php
header('Content-Type: text/html; charset=utf-8');
// 接收数据
$name = $_POST['student_name'];
$chinese = $_POST['chinese'];
$math = $_POST['math'];
$english = $_POST['english'];

// 计算总分和平均分
$total = $chinese + $math + $english;
$average = $total / 3;

// 显示结果
echo "<h2>成绩报告单</h2>";
echo "<p>学生：{$name}</p>";
echo "<p>语文：{$chinese} 分</p>";
echo "<p>数学：{$math} 分</p>";
echo "<p>英语：{$english} 分</p>";
echo "<hr>";
echo "<p><strong>总分：{$total} 分</strong></p>";
echo "<p><strong>平均分：{$average} 分</strong></p>";
?>
