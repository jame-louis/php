<?php
// 1. 简单IP验证（每段0-255）
function isValidIP($ip) {
    $pattern = '/^(\d{1,3}\.){3}\d{1,3}$/';
    if (!preg_match($pattern, $ip)) return false;

    // 进一步检查每段是否0-255
    $parts = explode('.', $ip);
    foreach ($parts as $part) {
        if ($part < 0 || $part > 255) return false;
    }
    return true;
}

// 2. 提取所有手机号
function extractPhones($text) {
    $pattern = '/1[3-9]\d{9}/';
    preg_match_all($pattern, $text, $matches);
    return $matches[0];
}

// 测试
var_dump(isValidIP("192.168.1.1"));
var_dump(isValidIP("256.1.1.1"));

$text = "联系人：13800138000，备用：13987654321，固话：010-12345678";
$phones = extractPhones($text);
print_r($phones);  // Array ( [0] => 13800138000 [1] => 13987654321 )
?>
