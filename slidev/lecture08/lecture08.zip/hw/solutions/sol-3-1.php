<?php
header('Content-Type: text/html; charset=utf-8');
function validateUser($data) {
    // 默认值
    $username = trim($data['username'] ?? '');
    $password = $data['password'] ?? '';
    $age = $data['age'] ?? 0;

    // 用户名验证
    if (empty($username)) {
        return ['valid' => false, 'message' => '用户名不能为空'];
    }
    if (strlen($username) < 3 || strlen($username) > 20) {
        return ['valid' => false, 'message' => '用户名长度必须在3-20个字符之间'];
    }

    // 密码验证
    if (empty($password)) {
        return ['valid' => false, 'message' => '密码不能为空'];
    }
    if (strlen($password) < 6) {
        return ['valid' => false, 'message' => '密码至少6位'];
    }

    // 年龄验证
    if (empty($age)) {
        return ['valid' => false, 'message' => '年龄不能为空'];
    }
    if ($age < 10 || $age > 100) {
        return ['valid' => false, 'message' => '年龄必须在10-100之间'];
    }

    return ['valid' => true, 'message' => '验证通过'];
}

// 测试
$result = validateUser(['username' => '张三', 'password' => '123456', 'age' => 25]);
var_dump($result);  // 通过

$result = validateUser(['username' => 'ab', 'password' => '123', 'age' => 5]);
var_dump($result);  // 失败
?>
