<?php
// 强密码验证
function isStrongPassword($pwd) {
    // 至少8位
    if (strlen($pwd) < 8) return false;

    // 包含小写字母
    if (!preg_match('/[a-z]/', $pwd)) return false;

    // 包含大写字母
    if (!preg_match('/[A-Z]/', $pwd)) return false;

    // 包含数字
    if (!preg_match('/\d/', $pwd)) return false;

    return true;
}

// URL验证
function isUrl($url) {
    $pattern = '/^https?:\/\/.+/';
    return preg_match($pattern, $url);
}

// 测试
var_dump(isStrongPassword("Hello123"));      // true
var_dump(isStrongPassword("hello123"));      // false (没有大写)
var_dump(isStrongPassword("Hello"));         // false (没有数字)

var_dump(isUrl("https://example.com"));      // true
var_dump(isUrl("ftp://example.com"));        // false
?>
