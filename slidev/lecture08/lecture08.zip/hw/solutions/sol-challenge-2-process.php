<?php
header('Content-Type: text/html; charset=utf-8');
// 验证函数
function validateScoreData($data) {
    $errors = [];

    // 姓名验证（2-4个汉字）
    $name = trim($data['name'] ?? '');
    if (!preg_match('/^[\x{4e00}-\x{9fa5}]{2,4}$/u', $name)) {
        $errors[] = '姓名必须是2-4个汉字';
    }

    // 成绩验证
    $subjects = ['chinese', 'math', 'english'];
    foreach ($subjects as $subject) {
        $score = $data[$subject] ?? '';
        if (!is_numeric($score) || $score < 0 || $score > 100) {
            $errors[] = '各科成绩必须是0-100之间的数字';
            break;
        }
    }

    return [
        'valid' => empty($errors),
        'errors' => $errors,
        'data' => [
            'name' => $name,
            'chinese' => (int)($data['chinese'] ?? 0),
            'math' => (int)($data['math'] ?? 0),
            'english' => (int)($data['english'] ?? 0)
        ]
    ];
}

// 获取等级
function getGrade($score) {
    if ($score >= 90) return ['level' => 'A', 'label' => '优秀'];
    if ($score >= 80) return ['level' => 'B', 'label' => '良好'];
    if ($score >= 60) return ['level' => 'C', 'label' => '及格'];
    return ['level' => 'D', 'label' => '不及格'];
}

// 主流程
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('请通过表单提交');
}

$result = validateScoreData($_POST);

if (!$result['valid']) {
    echo "<h3>验证失败</h3>";
    echo "<ul>";
    foreach ($result['errors'] as $error) {
        echo "<li>" . htmlspecialchars($error) . "</li>";
    }
    echo "</ul>";
    echo '<a href="form.html">返回重填</a>';
    exit;
}

// 数据计算
$d = $result['data'];
$total = $d['chinese'] + $d['math'] + $d['english'];
$average = round($total / 3, 1);
$totalGrade = getGrade($average);
?>

<!DOCTYPE html>
<html>
<head>
    <title>成绩报告单</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: center; }
        th { background-color: #4CAF50; color: white; }
        .total { background-color: #f0f0f0; font-weight: bold; }
        .grade-A { color: green; }
        .grade-D { color: red; }
    </style>
</head>
<body>
    <h2>成绩报告单</h2>
    <p>学生：<?php echo htmlspecialchars($d['name']); ?></p>

    <table>
        <tr>
            <th>科目</th>
            <th>成绩</th>
            <th>等级</th>
        </tr>
        <tr>
            <td>语文</td>
            <td><?php echo $d['chinese']; ?></td>
            <td><?php echo getGrade($d['chinese'])['label']; ?></td>
        </tr>
        <tr>
            <td>数学</td>
            <td><?php echo $d['math']; ?></td>
            <td><?php echo getGrade($d['math'])['label']; ?></td>
        </tr>
        <tr>
            <td>英语</td>
            <td><?php echo $d['english']; ?></td>
            <td><?php echo getGrade($d['english'])['label']; ?></td>
        </tr>
        <tr class="total">
            <td>总分</td>
            <td><?php echo $total; ?></td>
            <td><?php echo $totalGrade['label']; ?></td>
        </tr>
        <tr class="total">
            <td>平均分</td>
            <td><?php echo $average; ?></td>
            <td class="grade-<?php echo $totalGrade['level']; ?>">
                <?php echo $totalGrade['level']; ?>
            </td>
        </tr>
    </table>

    <a href="form.html">录入下一位</a>
</body>
</html>
