<?php
header('Content-Type: text/html; charset=utf-8');
$userData = [
    'name' => '<script>alert("hack")</script>张三',
    'bio' => '我喜欢编程，<b>特别</b>是PHP！'
];

// 净化函数：去除script标签但保留其他标签
function sanitize($str) {
    // 先转义所有HTML
    $safe = htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    // 允许<b>和<i>标签（可选）
    $allowed = '<b><i><strong><em>';
    return strip_tags($safe, $allowed);
}

echo "<p>姓名：" . sanitize($userData['name']) . "</p>";
echo "<p>简介：" . sanitize($userData['bio']) . "</p>";
?>
