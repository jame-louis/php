<?php
// 任务：编写 validateUser($data) 函数，验证用户注册信息：
// - 用户名：必填，3-20字符
// - 密码：必填，至少6位
// - 年龄：必填，10-100之间
// 返回数组：['valid' => true/false, 'message' => '错误信息']

function validateUser($data) {
    // 在此编写代码

}

// 测试
$result = validateUser(['username' => '张三', 'password' => '123456', 'age' => 25]);
var_dump($result);

$result = validateUser(['username' => 'ab', 'password' => '123', 'age' => 5]);
var_dump($result);
?>
