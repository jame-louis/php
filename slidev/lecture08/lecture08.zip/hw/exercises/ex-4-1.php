<?php
// 任务：编写验证函数：
// 1. isStrongPassword($pwd)：至少8位，包含大小写字母和数字
// 2. isUrl($url)：以http://或https://开头


// 测试
var_dump(isStrongPassword("Hello123"));
var_dump(isStrongPassword("hello123"));
var_dump(isStrongPassword("Hello"));

var_dump(isUrl("https://example.com"));
var_dump(isUrl("ftp://example.com"));
?>
