<?php
// 任务：使用正则表达式完成以下任务：
// 1. 验证IP地址（如192.168.1.1）
// 2. 提取字符串中的所有手机号


// 测试IP验证
var_dump(isValidIP("192.168.1.1"));
var_dump(isValidIP("256.1.1.1"));

// 测试手机号提取
$text = "联系人：13800138000，备用：13987654321，固话：010-12345678";
$phones = extractPhones($text);
print_r($phones);
?>
