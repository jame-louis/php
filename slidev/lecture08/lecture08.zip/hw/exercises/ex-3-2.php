<?php
// 任务：创建安全的用户信息显示页面
// 要求：安全地输出用户数据（保留<b>标签用于加粗，但过滤<script>）

$userData = [
    'name' => '<script>alert("hack")</script>张三',
    'bio' => '我喜欢编程，<b>特别</b>是PHP！'
];

// 在此编写代码

?>
