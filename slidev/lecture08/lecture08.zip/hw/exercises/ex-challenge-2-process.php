<?php
header('Content-Type: text/html; charset=utf-8');
// 挑战2：成绩管理系统（完整版）
// 需求：
// 1. 数据验证处理（process.php）
//    - 姓名：必填，2-4个汉字
//    - 各科成绩：0-100的数字
// 2. 显示结果页面（显示总分、平均分、等级）

// 验证函数
function validateScoreData($data) {
    // 在此编写代码

}

// 获取等级
function getGrade($score) {
    // 在此编写代码

}

// 主流程
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('请通过表单提交');
}

// 处理数据并显示结果
?>
