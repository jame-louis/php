<?php
// 挑战1：用户注册表单验证器
// 需求：创建一个完整的用户注册验证函数
// 验证规则：
// 1. 用户名：3-20位，字母开头，只允许字母数字下划线
// 2. 密码：8-20位，必须包含大小写字母和数字
// 3. 邮箱：标准邮箱格式
// 4. 手机号：中国大陆手机号
// 5. 年龄：18-60岁
// 返回：['success' => true/false, 'errors' => [...]]

function validateRegistration($data) {
    // 在此编写代码

}

// 测试
$test = [
    'username' => 'user123',
    'password' => 'Hello123',
    'email' => 'test@example.com',
    'phone' => '13800138000',
    'age' => 25
];
$result = validateRegistration($test);
var_dump($result);
?>
