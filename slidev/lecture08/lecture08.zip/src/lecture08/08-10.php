<?php
$userInput = "<script>alert('攻击')</script>";

// ❌ 危险：直接输出，会执行脚本
echo $userInput;

// ✅ 安全：转义特殊字符，变成纯文本
echo htmlspecialchars($userInput);
// 输出：&lt;script&gt;alert('攻击')&lt;/script&gt;  ← 浏览器不会执行
?>
