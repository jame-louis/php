<?php
// ❌ 直接访问会报错：Undefined index
$name = $_POST['name'];   // 报错！

// ✅ 先检查是否存在
if (isset($_POST['name'])) {
    $name = $_POST['name'];
} else {
    $name = "未填写";
}

// ✅ 更简洁的写法（PHP 7+）
$name = $_POST['name'] ?? "未填写";   // 如果不存在就用默认值
?>
