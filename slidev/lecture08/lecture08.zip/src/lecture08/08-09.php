<?php
// 第二层&第三层：PHP验证

// 1. 获取并清理数据（去除首尾空格）
$username = trim($_POST['username'] ?? '');
$email = trim($_POST['email'] ?? '');
$age = $_POST['age'] ?? 0;

// 2. 必填验证
if (empty($username)) {
    die('用户名不能为空');
}

// 3. 长度验证
if (strlen($username) < 3 || strlen($username) > 20) {
    die('用户名长度必须在3-20个字符之间');
}

// 4. 范围验证
if ($age < 1 || $age > 120) {
    die('年龄必须在1-120之间');
}

// 5. 邮箱格式验证（简单版）
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die('邮箱格式不正确');
}

echo "验证通过！欢迎 {$username}";
?>
