<?php
// 1. 验证邮箱
function isEmail($email) {
    $pattern = '/^[\w.-]+@[\w.-]+\.\w+$/';
    return preg_match($pattern, $email);
}
// 解释：[\w.-]+ 用户名（字母数字下划线.和-）
//       @       @符号
//       [\w.-]+ 域名部分
//       \.      点号
//       \w+     后缀（com/cn等）

// 2. 验证用户名（字母开头，允许字母数字下划线，3-20位）
function isUsername($username) {
    $pattern = '/^[a-zA-Z]\w{2,19}$/';
    return preg_match($pattern, $username);
}

// 3. 验证中文姓名（2-4个汉字）
function isChineseName($name) {
    $pattern = '/^[\x{4e00}-\x{9fa5}]{2,4}$/u';
    return preg_match($pattern, $name);
}

// 测试
var_dump(isEmail("test@example.com"));     // 1 (true)
var_dump(isEmail("invalid-email"));         // 0 (false)
var_dump(isUsername("user123"));            // 1
var_dump(isChineseName("张三"));            // 1
?>
