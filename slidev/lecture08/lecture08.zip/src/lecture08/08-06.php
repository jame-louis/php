<?php
// 表单：method="POST"

// 用$_POST数组接收数据
$username = $_POST['username'];
$password = $_POST['password'];
?>
