<?php
// 检查是否包含"PHP"
$pattern = '/PHP/';
$text = '我爱PHP编程';

if (preg_match($pattern, $text)) {
    echo "包含'PHP'";
}

// 匹配邮箱（简单版）
$email = "user@example.com";
$pattern = '/@/';   // 包含@符号
if (preg_match($pattern, $email)) {
    echo "可能是邮箱";
}
?>
