<?php
// 将所有数字替换为*
$text = "我的电话是13800138000，生日是1990年";
$result = preg_replace('/\d/', '*', $text);
echo $result;  // 我的电话是***********，生日是****年

// 隐藏手机号中间4位
$phone = "13800138000";
$result = preg_replace('/(\d{3})\d{4}(\d{4})/', '$1****$2', $phone);
echo $result;  // 138****8000

// 提取所有邮箱
$text = "联系我：a@qq.com 或 b@gmail.com";
preg_match_all('/[\w.-]+@[\w.-]+\.\w+/', $text, $matches);
print_r($matches[0]);  // Array ( [0] => a@qq.com [1] => b@gmail.com )
?>
