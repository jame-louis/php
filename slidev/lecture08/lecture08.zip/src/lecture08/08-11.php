<?php
$str = '<a href="test">测试 & "例子"</a>';

// 默认只转义 < 和 >
echo htmlspecialchars($str);        // &lt;a href=&quot;test&quot;&gt;测试 & &quot;例子&quot;&lt;/a&gt;

// ENT_QUOTES: 也转义单引号
echo htmlspecialchars($str, ENT_QUOTES);

// ENT_HTML5: 使用HTML5标准

// 推荐写法
$output = htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
?>
