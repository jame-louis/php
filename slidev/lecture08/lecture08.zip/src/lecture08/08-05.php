<?php
// 表单：method="GET"
// URL: search.php?keyword=手机&page=1

// 用$_GET数组接收数据
$keyword = $_GET['keyword'];   // "手机"
$page = $_GET['page'];         // "1"
?>
