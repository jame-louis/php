<?php
// 动手练 2.2：编写 sendEmail($to, $subject = "无主题", $priority = "普通") 函数
// 输出如下:
// 收件人：user@example.com
// 主题：无主题
// 优先级：普通
// ---

// 你的代码在这里


// 测试用例：
sendEmail("user@example.com");
sendEmail("boss@example.com", "紧急通知");
sendEmail("test@example.com", "测试", "高");
?>