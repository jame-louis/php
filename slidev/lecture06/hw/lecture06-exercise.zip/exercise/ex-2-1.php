<?php
// 动手练 2.1：编写 calculateArea($width, $height) 函数
// 计算并输出矩形面积

// 你的代码在这里


// 测试
calculateArea(5, 3);   // 输出：矩形面积：15
calculateArea(10, 4);  // 输出：矩形面积：40
?>