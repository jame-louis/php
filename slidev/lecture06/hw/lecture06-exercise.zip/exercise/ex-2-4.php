<?php
// 动手练 2.4：编写 doubleValues(&$a, &$b) 函数
// 将两个变量的值都变为原来的2倍（使用引用传递）

// 你的代码在这里


// 测试
$x = 3;
$y = 5;
doubleValues($x, $y);
echo "x={$x}, y={$y}";   // 输出：x=6, y=10
?>