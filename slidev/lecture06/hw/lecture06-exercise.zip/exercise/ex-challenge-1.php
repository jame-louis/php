<?php
// 挑战1：文件扩展名检查器
// 检查 $filename 的扩展名是否在 $allowed 数组中
// 不区分大小写，返回 true 或 false

function checkExtension($filename, $allowed) {
    // 你的代码在这里
}

// 测试用例
var_dump(checkExtension("photo.jpg", ["jpg", "png"]));     // true
var_dump(checkExtension("doc.PDF", ["pdf", "doc"]));        // true
var_dump(checkExtension("virus.exe", ["jpg", "png"]));     // false
var_dump(checkExtension("README", ["txt"]));               // false
?>