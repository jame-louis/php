<?php
// 动手练 2.3：编写 average(...$scores) 函数
// 计算任意数量成绩的平均分

// 你的代码在这里


// 测试
echo average(80, 90, 100);     // 90
echo average(60, 70);          // 65
echo average();                // 0
?>