<?php
// 动手练 3.2：编写 analyzeString($str) 函数
// 返回数组包含：
// - length：字符串长度
// - uppercase：转大写后的字符串
// - first_char：首字符

// 你的代码在这里


// 测试
$result = analyzeString("Hello");
echo "长度：" . $result['length'];        // 5
echo "大写：" . $result['uppercase'];    // HELLO
echo "首字符：" . $result['first_char'];  // H
?>