<?php
// 动手练 4：编写 visitCount() 函数
// 使用静态变量统计页面访问次数（每次调用计数+1）

// 你的代码在这里


// 测试
echo visitCount();  // 1
echo visitCount();  // 2
echo visitCount();  // 3
?>