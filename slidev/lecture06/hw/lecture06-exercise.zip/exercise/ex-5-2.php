<?php
// 动手练 5.2：解析路径 "/home/user/documents/file.txt"
// 提取：1. 文件名（file.txt）2. 扩展名（txt）3. 目录路径（/home/user/documents）

$path = "/home/user/documents/file.txt";

// 你的代码在这里

?>