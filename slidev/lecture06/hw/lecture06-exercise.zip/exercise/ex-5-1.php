<?php
// 动手练 5.1：使用字符串函数完成以下任务

$str = "The quick brown fox jumps over the lazy dog";

// 任务1：将 fox 替换为 cat


// 任务2：提取前9个字符（The quick）


// 任务3：查找 dog 的位置

?>