<?php
// 动手练 3.1：编写 getGrade($score) 函数，返回成绩等级
// 90-100：优秀
// 80-89：良好
// 60-79：及格
// 0-59：不及格
// 其他：无效分数

// 你的代码在这里


// 测试
echo getGrade(95);   // 优秀
echo getGrade(85);   // 良好
echo getGrade(70);   // 及格
echo getGrade(50);   // 不及格
echo getGrade(150);  // 无效分数
?>