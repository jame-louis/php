<?php
// 挑战2：表格生成器
// 编写 printTable($rows, $cols, $options = []) 函数

function printTable($rows, $cols, $options = []) {
    // 你的代码在这里
}

// 测试
printTable(4, 4);
printTable(3, 3, ['header' => false, 'header_bg' => '#2196F3']);
?>