<?php
// code
session_start();

// 先处理重置请求（必须在任何输出之前）
if (isset($_GET['reset'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// 检查是否是第一次访问
if (!isset($_SESSION['count'])) {
    $_SESSION['count'] = 0;
}

// 计数 +1
$_SESSION['count']++;

// 保存本次访问时间（供下次显示）
$current_visit = date('Y-m-d H:i:s');
if (isset($_SESSION['last_visit'])) {
    $last_visit = $_SESSION['last_visit'];
}
$_SESSION['last_visit'] = $current_visit;
?>
<!DOCTYPE html>
<html>
<head>
    <title>访问计数器</title>
    <style>
        body {
            font-family: 'Microsoft YaHei', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .counter-box {
            background: white;
            padding: 40px 60px;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            text-align: center;
        }
        .count-number {
            font-size: 72px;
            color: #667eea;
            font-weight: bold;
            margin: 20px 0;
        }
        .info {
            color: #666;
            margin-top: 15px;
            font-size: 14px;
        }
        button {
            margin-top: 20px;
            padding: 10px 30px;
            font-size: 16px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            margin-right: 10px;
        }
        button:hover {
            background: #764ba2;
        }
        .btn-reset {
            background: #e74c3c;
        }
        .btn-reset:hover {
            background: #c0392b;
        }
    </style>
</head>
<body>
    <div class="counter-box">
        <h2>🎯 访问计数器</h2>
        <div class="count-number"><?php echo $_SESSION['count']; ?></div>
        <p>这是您第 <?php echo $_SESSION['count']; ?> 次访问本页面</p>
        <p class="info">Session ID: <?php echo session_id(); ?></p>
        <?php if (isset($last_visit)): ?>
            <p class="info">上次访问: <?php echo $last_visit; ?></p>
        <?php endif; ?>
        <br>
        <button onclick="location.reload()">🔄 刷新页面</button>
        <button class="btn-reset" onclick="location.href='?reset=1'">🗑️ 重置计数</button>
    </div>
</body>
</html>
