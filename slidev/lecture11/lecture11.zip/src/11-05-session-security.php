<?php
// 1. 启动Session时设置安全参数
ini_set('session.cookie_httponly', 1);    // 防止JavaScript访问
ini_set('session.cookie_secure', 1);         // 仅HTTPS传输
ini_set('session.use_strict_mode', 1);       // 严格模式

session_start();

// 2. 重新生成Session ID（防止Session Fixation攻击）
// 在登录成功后调用
if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true) {
    session_regenerate_id(true);
}

// 3. 验证Session有效性
if (isset($_SESSION['ip']) && $_SESSION['ip'] !== $_SERVER['REMOTE_ADDR']) {
    // IP地址改变，可能是Session劫持
    session_destroy();
    die("安全验证失败，请重新登录");
}
?>
