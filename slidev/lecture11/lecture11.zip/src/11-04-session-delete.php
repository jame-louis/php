<?php
session_start();

// 删除单个Session变量
unset($_SESSION['username']);
unset($_SESSION['age']);

// 清空所有Session数据（但保留Session ID）
$_SESSION = [];

// 完全销毁Session（包括ID和文件）
session_destroy();

// 同时删除Cookie中的Session ID
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}
?>
