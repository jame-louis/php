<?php
/**
 * 添加商品到购物车（简化版 - 不使用引用&）
 */
function addToCart($product) {
    // 初始化购物车
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = ['items' => []];
    }

    $items = $_SESSION['cart']['items'];

    // 检查商品是否已存在
    foreach ($items as $key => $item) {
        if ($item['id'] === $product['id']) {
            // 存在则增加数量
            $_SESSION['cart']['items'][$key]['quantity'] += $product['quantity'] ?? 1;
            updateCartTotals();
            return true;
        }
    }

    // 添加新商品
    $_SESSION['cart']['items'][] = [
        'id' => $product['id'],
        'name' => $product['name'],
        'price' => $product['price'],
        'quantity' => $product['quantity'] ?? 1
    ];

    updateCartTotals();
    return true;
}

/**
 * 更新购物车统计
 */
function updateCartTotals() {
    $items = $_SESSION['cart']['items'] ?? [];
    $totalItems = 0;
    $totalPrice = 0;

    foreach ($items as $item) {
        $totalItems += $item['quantity'];
        $totalPrice += $item['price'] * $item['quantity'];
    }

    $_SESSION['cart']['total_items'] = $totalItems;
    $_SESSION['cart']['total_price'] = $totalPrice;
}

/**
 * 修改商品数量（简化版 - 不使用引用&）
 */
function updateQuantity($productId, $quantity) {
    if ($quantity < 1) {
        removeFromCart($productId);
        return;
    }

    foreach ($_SESSION['cart']['items'] as $key => $item) {
        if ($item['id'] === (int)$productId) {
            // 直接通过 $_SESSION 修改
            $_SESSION['cart']['items'][$key]['quantity'] = $quantity;
            updateCartTotals();
            return;
        }
    }
}

/**
 * 从购物车移除商品（简化版 - 不使用引用&）
 */
function removeFromCart($productId) {
    $items = $_SESSION['cart']['items'];

    foreach ($items as $key => $item) {
        if ($item['id'] === (int)$productId) {
            unset($_SESSION['cart']['items'][$key]);
            // 重新索引数组
            $_SESSION['cart']['items'] = array_values($_SESSION['cart']['items']);
            updateCartTotals();
            return;
        }
    }
}

/**
 * 清空购物车
 */
function clearCart() {
    unset($_SESSION['cart']);
}

/**
 * 获取购物车数据
 */
function getCart() {
    return $_SESSION['cart'] ?? [
        'items' => [],
        'total_items' => 0,
        'total_price' => 0
    ];
}
?>
