<?php
// 购物车数据结构（存储在Session中）
$_SESSION['cart'] = [
    'items' => [
        [
            'id' => 1,
            'name' => 'iPhone 15',
            'price' => 5999,
            'quantity' => 1
        ],
        [
            'id' => 3,
            'name' => 'AirPods',
            'price' => 1299,
            'quantity' => 2
        ]
    ],
    'total_items' => 3,
    'total_price' => 8597
];
?>
