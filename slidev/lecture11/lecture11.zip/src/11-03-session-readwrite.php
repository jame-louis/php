<?php
session_start();

// 写入数据（支持各种数据类型）
$_SESSION['username'] = '张三';
$_SESSION['age'] = 25;
$_SESSION['is_logged_in'] = true;
$_SESSION['cart'] = ['item1', 'item2'];  // 数组
$_SESSION['user'] = [
    'id' => 1,
    'name' => '张三',
    'email' => 'zhangsan@example.com'
];  // 关联数组

// 读取数据
$username = $_SESSION['username'];
$age = $_SESSION['age'];

// 安全读取（防止未定义索引错误）
$theme = $_SESSION['theme'] ?? 'light';  // 默认值
$language = $_SESSION['lang'] ?? 'zh';

// 检查是否存在
if (isset($_SESSION['is_logged_in'])) {
    echo "已登录";
}
?>
