<?php
// ❌ 错误：先输出了内容
echo "Hello";
session_start();  // 报错：headers already sent

// ❌ 错误：BOM头导致的问题
// 文件以UTF-8 with BOM保存
// BOM字符在<?php之前就被输出了
?>
