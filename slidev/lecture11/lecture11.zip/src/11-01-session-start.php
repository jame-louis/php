<?php
// session_start() - 必须在任何输出之前调用
session_start();

// 之后才能使用$_SESSION
$_SESSION['username'] = '张三';
?>
