<?php
// 练习：登录系统
// 要求：
// 1. 创建用户名/密码表单
// 2. 使用Session保存登录状态
// 3. 密码使用简单验证（如 admin/123456）

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // TODO: 实现登录验证逻辑
    // 提示：如果用户名和密码正确，设置$_SESSION['is_logged_in'] = true
    // 然后跳转到 products.php
    if($username === 'admin' && $password === '123456'){
        $_SESSION['is_logged_in'] = true;
        header("Location: products.php");
        exit;
    } else {
        $error = "用户名或密码错误";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>用户登录</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 100px auto; }
        form { border: 1px solid #ddd; padding: 30px; border-radius: 8px; }
        input { width: 100%; padding: 10px; margin: 10px 0; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #4CAF50; color: white; border: none; cursor: pointer; }
        .error { color: red; margin-bottom: 10px; }
    </style>
</head>
<body>
    <h2 style="text-align: center;">用户登录</h2>

    <!-- TODO: 显示错误信息 -->

    <form method="POST">
        <input type="text" name="username" placeholder="用户名" required>
        <input type="password" name="password" placeholder="密码" required>
        <button type="submit">登录</button>
    </form>
</body>
</html>
