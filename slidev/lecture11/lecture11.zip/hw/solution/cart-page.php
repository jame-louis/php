<?php
session_start();
require_once 'cart-functions.php';

// todo: 检查用户是否登录
if(!isset($_SESSION['is_logged_in'])){
    header("Location: login.php");
    exit;
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update':
                updateQuantity($_POST['product_id'], (int)$_POST['quantity']);
                break;
            case 'remove':
                removeFromCart($_POST['product_id']);
                break;
            case 'clear':
                clearCart();
                break;
        }
    }

    header("Location: cart-page.php");
    exit;
}

$cart = getCart();
?>
<!DOCTYPE html>
<html>
<head>
    <title>购物车</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: center; }
        th { background-color: #4CAF50; color: white; }
        .empty { color: #666; padding: 50px; text-align: center; }
        .total { background-color: #f0f0f0; font-weight: bold; }
        input[type="number"] { width: 60px; padding: 5px; }
        button { padding: 5px 15px; cursor: pointer; }
        .btn-update { background: #2196F3; color: white; border: none; }
        .btn-remove { background: #f44336; color: white; border: none; }
        .btn-clear { background: #ff9800; color: white; border: none; padding: 10px 20px; }
        .continue { display: inline-block; margin-top: 20px; color: #4CAF50; }
    </style>
</head>
<body>
    <h2>🛒 我的购物车</h2>

    <?php if (empty($cart['items'])): ?>
        <div class="empty">
            <p>购物车是空的~</p>
            <a href="products.php" class="continue">去购物 →</a>
        </div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>商品名称</th>
                    <th>单价</th>
                    <th>数量</th>
                    <th>小计</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cart['items'] as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                        <td>¥<?php echo number_format($item['price'], 2); ?></td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" style="width:60px;">
                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                <button type="submit" name="action" value="update" class="btn-update">更新</button>
                            </form>
                        </td>
                        <td>¥<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                <button type="submit" name="action" value="remove" class="btn-remove">删除</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="total">
                    <td colspan="2"><strong>总计</strong></td>
                    <td><strong><?php echo $cart['total_items']; ?> 件</strong></td>
                    <td colspan="2"><strong>¥<?php echo number_format($cart['total_price'], 2); ?></strong></td>
                </tr>
            </tfoot>
        </table>

        <form method="POST" style="text-align: right;">
            <button type="submit" name="action" value="clear" class="btn-clear">清空购物车</button>
            <a href="products.php" class="continue">继续购物 →</a>
        </form>
    <?php endif; ?>

</body>
</html>
