<?php
session_start();
require_once 'cart-functions.php';

// todo: 检查用户是否登录

// 模拟商品数据
$products = [
    ['id' => 1, 'name' => '🍎 苹果', 'price' => 5.00, 'image' => '🍎'],
    ['id' => 2, 'name' => '🍌 香蕉', 'price' => 3.00, 'image' => '🍌'],
    ['id' => 3, 'name' => '🍊 橙子', 'price' => 4.50, 'image' => '🍊'],
    ['id' => 4, 'name' => '🍇 葡萄', 'price' => 12.00, 'image' => '🍇'],
    ['id' => 5, 'name' => '🍓 草莓', 'price' => 8.00, 'image' => '🍓'],
    ['id' => 6, 'name' => '🍉 西瓜', 'price' => 15.00, 'image' => '🍉'],
];

// 处理添加到购物车
if (isset($_POST['add_to_cart'])) {
    $productId = $_POST['product_id'];

    // 查找商品
    foreach ($products as $p) {
        if ($p['id'] == $productId) {
            addToCart([
                'id' => $p['id'],
                'name' => $p['name'],
                'price' => $p['price'],
                'quantity' => 1
            ]);
            break;
        }
    }

    header('Location: products.php?added=1');
    exit;
}

$cart = getCart();
$cartCount = $cart['total_items'] ?? 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>商品列表</title>
    <style>
        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }
        h2 { text-align: center; color: #333; }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .cart-link {
            text-decoration: none;
            padding: 10px 20px;
            background: #4CAF50;
            color: white;
            border-radius: 5px;
        }
        .cart-count {
            background: #ff5722;
            color: white;
            padding: 2px 8px;
            border-radius: 50%;
            font-size: 14px;
            margin-left: 5px;
        }
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
        }
        .product-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .product-icon {
            font-size: 80px;
            margin: 10px 0;
        }
        .product-name {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
        }
        .product-price {
            font-size: 24px;
            color: #e74c3c;
            font-weight: bold;
            margin: 10px 0;
        }
        .add-btn {
            background: #4CAF50;
            color: white;
            border: none;
            padding: 12px 30px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        .add-btn:hover {
            background: #45a049;
        }
        .success-msg {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>🛍️ 商品列表</h2>
        <a href="cart-page.php" class="cart-link">
            🛒 购物车
            <?php if ($cartCount > 0): ?>
                <span class="cart-count"><?php echo $cartCount; ?></span>
            <?php endif; ?>
        </a>
    </div>

    <?php if (isset($_GET['added'])): ?>
        <div class="success-msg">✅ 商品已添加到购物车！</div>
    <?php endif; ?>

    <div class="products-grid">
        <?php foreach ($products as $product): ?>
            <div class="product-card">
                <div class="product-icon"><?php echo $product['image']; ?></div>
                <div class="product-name"><?php echo $product['name']; ?></div>
                <div class="product-price">¥<?php echo number_format($product['price'], 2); ?></div>
                <form method="POST">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    <button type="submit" name="add_to_cart" class="add-btn">加入购物车</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>

</body>
</html>
