<?php
/**
 * 添加商品到购物车
 */
function addToCart($product) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = ['items' => []];
    }

    $items = &$_SESSION['cart']['items'];

    // 检查是否已存在
    foreach ($items as &$item) {
        if ($item['id'] === $product['id']) {
            $item['quantity'] += $product['quantity'] ?? 1;
            updateCartTotals();
            return true;
        }
    }

    // 添加新商品
    $items[] = [
        'id' => $product['id'],
        'name' => $product['name'],
        'price' => $product['price'],
        'quantity' => $product['quantity'] ?? 1
    ];

    updateCartTotals();
    return true;
}

/**
 * 更新购物车统计
 */
function updateCartTotals() {
    $items = $_SESSION['cart']['items'] ?? [];
    $totalItems = 0;
    $totalPrice = 0;

    foreach ($items as $item) {
        $totalItems += $item['quantity'];
        $totalPrice += $item['price'] * $item['quantity'];
    }

    $_SESSION['cart']['total_items'] = $totalItems;
    $_SESSION['cart']['total_price'] = $totalPrice;
}

/**
 * 修改商品数量
 */
function updateQuantity($productId, $quantity) {
    if ($quantity < 1) {
        removeFromCart($productId);
        return;
    }

    foreach ($_SESSION['cart']['items'] as &$item) {
        if ($item['id'] === (int)$productId) {
            $item['quantity'] = $quantity;
            updateCartTotals();
            return;
        }
    }
}

/**
 * 从购物车移除商品
 */
function removeFromCart($productId) {
    $items = &$_SESSION['cart']['items'];

    foreach ($items as $key => $item) {
        if ($item['id'] === (int)$productId) {
            unset($items[$key]);
            $items = array_values($items);  // 重新索引
            updateCartTotals();
            return;
        }
    }
}

/**
 * 清空购物车
 */
function clearCart() {
    unset($_SESSION['cart']);
}

/**
 * 获取购物车数据
 */
function getCart() {
    return $_SESSION['cart'] ?? [
        'items' => [],
        'total_items' => 0,
        'total_price' => 0
    ];
}
?>
