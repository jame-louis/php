<?php
// #region code
/**
 * 练习：个性化欢迎页面 - 参考答案
 */

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['name'])) {
    setcookie("visitor_name", $_POST['name'], time() + 30 * 24 * 3600);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// 检查是否有Cookie
$name = $_COOKIE['visitor_name'] ?? null;
// #endregion code
?>
<!DOCTYPE html>
<html>
<head>
    <title>个性化欢迎</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding-top: 100px; }
        .welcome { color: #4CAF50; font-size: 2em; }
        form { margin-top: 20px; }
        input { padding: 10px; font-size: 16px; }
        button { padding: 10px 20px; background: #4CAF50; color: white; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <?php if ($name): ?>
        <div class="welcome">欢迎回来，<?php echo htmlspecialchars($name); ?>！</div>
        <p>上次访问时间：<?php echo $_COOKIE['last_visit'] ?? '未知'; ?></p>
        <?php setcookie("last_visit", date('Y-m-d H:i:s'), time() + 30 * 24 * 3600); ?>
    <?php else: ?>
        <h2>欢迎来到我的网站</h2>
        <p>请告诉我你的名字：</p>
        <form method="POST">
            <input type="text" name="name" placeholder="你的名字" required>
            <button type="submit">开始体验</button>
        </form>
    <?php endif; ?>
</body>
</html>
