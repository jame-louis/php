<?php
/**
 * 挑战：记住我登录系统 - 登录页面（参考答案）
 */
?>
<!DOCTYPE html>
<html>
<head>
    <title>登录</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 100px auto; }
        input { width: 100%; padding: 10px; margin: 10px 0; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #4CAF50; color: white; border: none; cursor: pointer; }
        label { display: block; margin: 10px 0; }
    </style>
</head>
<body>
    <form method="POST" action="sol-challenge-do_login.php">
        <h2>用户登录</h2>
        <input type="text" name="username" placeholder="用户名" required>
        <input type="password" name="password" placeholder="密码" required>
        <label>
            <input type="checkbox" name="remember" value="1"> 记住我
        </label>
        <button type="submit">登录</button>
    </form>
</body>
</html>
