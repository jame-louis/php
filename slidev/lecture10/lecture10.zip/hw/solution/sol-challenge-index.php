<?php
/**
 * 挑战：记住我登录系统 - 主页
 */

if (!isset($_COOKIE['is_logged_in'])) {
    header("Location: sol-challenge-login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>主页</title>
</head>
<body>
    <h2>欢迎，<?php echo htmlspecialchars($_COOKIE['user'] ?? '用户'); ?>！</h2>
    <p><a href="sol-challenge-logout.php">退出登录</a></p>
</body>
</html>
