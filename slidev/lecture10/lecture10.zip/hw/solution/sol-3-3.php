<?php
// #region code
/**
 * 练习：登出功能 - 参考答案
 */

// 删除用户相关Cookie
setcookie("username", "", time() - 3600);
setcookie("user_id", "", time() - 3600);
setcookie("is_logged_in", "", time() - 3600);
setcookie("last_visit", "", time() - 3600);
// #endregion code
?>
<!DOCTYPE html>
<html>
<head>
    <title>已登出</title>
    <meta http-equiv="refresh" content="3;url=login.php">
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding-top: 100px; }
        .message { color: #4CAF50; font-size: 1.5em; }
        .countdown { color: #666; }
    </style>
</head>
<body>
    <div class="message">✓ 已成功登出</div>
    <p class="countdown">3秒后自动跳转到登录页面...</p>
    <p><a href="login.php">立即跳转</a></p>
</body>
</html>
