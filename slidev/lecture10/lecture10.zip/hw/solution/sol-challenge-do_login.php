<?php
/**
 * 挑战：记住我登录系统 - 处理登录
 */

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';
$remember = isset($_POST['remember']);

// 验证（实际应从数据库验证）
if ($username === 'admin' && $password === '123456') {
    // 设置Cookie
    $expire = $remember ? time() + 7 * 24 * 3600 : 0;
    setcookie("user", $username, $expire);
    setcookie("is_logged_in", "1", $expire);

    header("Location: sol-challenge-index.php");
    exit;
} else {
    echo "用户名或密码错误";
}
?>
