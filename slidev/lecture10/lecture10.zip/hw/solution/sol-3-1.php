<?php
// #region code
/**
 * 练习：设置3个Cookie - 参考答案
 */

// 1. 设置用户名（7天）
setcookie("username", "张三", time() + 7 * 24 * 3600);
$username = "张三";

// 2. 访问计数器
$count = $_COOKIE['visit_count'] ?? 0;
$count++;
setcookie("visit_count", $count, time() + 365 * 24 * 3600);

// 3. 上次访问时间
$lastVisit = $_COOKIE['last_visit'] ?? '首次访问';
setcookie("last_visit", date('Y-m-d H:i:s'), time() + 365 * 24 * 3600);

echo "<h2>Cookie设置成功</h2>";
echo "<p>用户名：{$username}</p>";
echo "<p>访问次数：{$count}</p>";
echo "<p>上次访问：{$lastVisit}</p>";
// #endregion code
?>
