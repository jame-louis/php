<?php
/**
 * 挑战：记住我登录系统 - 登出
 */

// 删除Cookie
setcookie("user", "", time() - 3600);
setcookie("is_logged_in", "", time() - 3600);

header("Location: sol-challenge-login.php");
exit;
?>
