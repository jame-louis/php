<?php
// #region code
/**
 * 练习：登出功能
 *
 * 1. 删除所有用户相关的Cookie
 * 2. 显示"已成功登出"信息
 * 3. 3秒后自动跳转到登录页
 */

// TODO: 删除所有用户相关的Cookie


// #endregion code
?>
<!DOCTYPE html>
<html>
<head>
    <title>已登出</title>
    <!-- TODO: 添加3秒后自动跳转到login.php -->
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding-top: 100px; }
        .message { color: #4CAF50; font-size: 1.5em; }
        .countdown { color: #666; }
    </style>
</head>
<body>
    <div class="message">✓ 已成功登出</div>
    <p class="countdown">3秒后自动跳转到登录页面...</p>
    <p><a href="login.php">立即跳转</a></p>
</body>
</html>
