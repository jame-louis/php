<?php
/**
 * 挑战：记住我登录系统 - 登出
 *
 * 需求：
 * 1. 删除所有与用户登录相关的Cookie
 * 2. 跳转到 ex-challenge-login.php
 */

// TODO: 删除用户相关的Cookie

// TODO: 跳转到登录页面

?>
