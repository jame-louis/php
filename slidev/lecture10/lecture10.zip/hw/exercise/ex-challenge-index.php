<?php
/**
 * 挑战：记住我登录系统 - 主页
 *
 * 需求：
 * 1. 检查用户是否已登录（通过Cookie判断）
 * 2. 未登录则跳转到 ex-challenge-login.php
 * 3. 显示欢迎信息和退出链接
 */

// TODO: 检查登录状态，未登录则跳转

?>
<!DOCTYPE html>
<html>
<head>
    <title>主页</title>
</head>
<body>
    <!-- TODO: 显示欢迎信息和退出链接 -->

</body>
</html>
