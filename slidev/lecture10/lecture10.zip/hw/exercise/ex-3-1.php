<?php
// #region code
/**
 * 练习：设置3个Cookie
 * 1. username - 保存你的名字，7天有效期
 * 2. visit_count - 访问计数器（每次访问+1）
 * 3. last_visit - 上次访问时间
 */

// 在此编写你的代码


echo "<h2>Cookie设置成功</h2>";
// 显示设置结果
echo "<p>用户名：{$username}</p>";
echo "<p>访问次数：{$count}</p>";
echo "<p>上次访问：{$lastVisit}</p>";
// #endregion code
?>
