<?php
/**
 * 挑战：记住我登录系统 - 登录页面
 *
 * 需求：
 * 1. 用户名/密码输入
 * 2. "记住我"复选框
 * 3. 提交到 ex-challenge-do_login.php
 */
?>
<!DOCTYPE html>
<html>
<head>
    <title>登录</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 100px auto; }
        input { width: 100%; padding: 10px; margin: 10px 0; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #4CAF50; color: white; border: none; cursor: pointer; }
        label { display: block; margin: 10px 0; }
    </style>
</head>
<body>
    <!-- TODO: 创建登录表单 -->

</body>
</html>
