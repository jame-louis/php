<?php
// 不推荐的方式（安全性差）
// setcookie("data", serialize(['name' => '张三', 'age' => 25]));

// 推荐：使用JSON
$userData = [
    'name' => '张三',
    'preferences' => ['theme' => 'dark', 'lang' => 'zh']
];

// 保存（30天有效期）
setcookie("user_prefs", json_encode($userData), time() + 30 * 24 * 3600);

// 读取
if (isset($_COOKIE['user_prefs'])) {
    $data = json_decode($_COOKIE['user_prefs'], true);
    echo "主题：" . ($data['preferences']['theme'] ?? 'light');
}
?>
