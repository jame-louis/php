<?php
// setcookie(name, value, expire, path, domain, secure, httponly)

// 最简单的设置（会话Cookie，关闭浏览器即失效）
setcookie("username", "张三");

// 设置持久Cookie（1小时后过期）
setcookie("username", "张三", time() + 3600);

// 设置7天有效期的Cookie
setcookie("remember", "yes", time() + 7 * 24 * 3600);

// 设置特定路径可用的Cookie
setcookie("admin", "true", time() + 3600, "/admin/");
?>
