<?php
// 通过 $_COOKIE 超全局数组读取

// 检查Cookie是否存在
if (isset($_COOKIE['username'])) {
    echo "欢迎回来，" . $_COOKIE['username'];
} else {
    echo "请先登录";
}

// 使用 ?? 提供默认值
$theme = $_COOKIE['theme'] ?? 'light';  // 默认浅色主题
$language = $_COOKIE['lang'] ?? 'zh';   // 默认中文

// 读取并解码数组Cookie（需要反序列化）
if (isset($_COOKIE['preferences'])) {
    $prefs = unserialize($_COOKIE['preferences']);
    // 注意：这种方法有安全风险，推荐使用JSON
}

// 安全的数组存储方式（JSON）
if (isset($_COOKIE['settings'])) {
    $settings = json_decode($_COOKIE['settings'], true);
}
?>
