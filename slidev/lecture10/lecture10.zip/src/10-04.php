<?php
// 方法1：设置过期时间为过去的时间（推荐）
setcookie("username", "", time() - 3600);

// 方法2：设置空值
setcookie("username", "");

// 删除特定路径的Cookie
setcookie("admin", "", time() - 3600, "/admin/");

// 删除后跳转
header("Location: login.php");
exit;
?>
