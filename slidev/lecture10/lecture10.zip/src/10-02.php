<?php
// ✅ 正确：setcookie在输出之前
cookie("user", "test");
echo "Cookie已设置";

// ❌ 错误：已经有输出了
// echo "Hello";
// setcookie("user", "test");  // 会报错！
?>
