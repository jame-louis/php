<?php
// 文件操作三步骤示例

// 第1步：打开文件（获取"钥匙"）
$file = fopen("data.txt", "r");   // r = read（只读）

// 第2步：读写操作
$content = fread($file, filesize("data.txt"));  // 读取内容

// 第3步：关闭文件（归还"钥匙"）
fclose($file);

echo $content;
?>