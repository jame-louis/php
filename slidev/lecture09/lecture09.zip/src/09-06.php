<?php
// 目录操作示例

// 创建目录
mkdir("uploads");
mkdir("uploads/2024", 0777, true);  // 递归创建

// 检查是否为目录
if (is_dir("uploads")) {
    echo "uploads是目录\n";
}

// 遍历目录
echo "目录内容：\n";
$files = scandir("uploads");
foreach ($files as $file) {
    if ($file != "." && $file != "..") {
        echo "- $file\n";
    }
}

// 使用glob查找图片
$images = glob("uploads/*.jpg");
echo "找到 " . count($images) . " 张图片";
?>