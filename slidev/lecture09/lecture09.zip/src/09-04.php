<?php
// 写入文件示例

// 方法1：传统方法（追加）
$file = fopen("log.txt", "a");
fwrite($file, "用户登录：张三\n");
fclose($file);

// 方法2：简便方法（覆盖写入）
file_put_contents("data.txt", "新的内容");

// 方法3：简便方法（追加写入）
file_put_contents("log.txt", "新的日志\n", FILE_APPEND);

echo "写入完成";
?>