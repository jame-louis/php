<?php
// 检查文件是否存在

// 检查文件是否存在
if (file_exists("data.txt")) {
    echo "文件存在\n";
} else {
    echo "文件不存在\n";
}

// 检查文件是否可读
if (is_readable("data.txt")) {
    echo "文件可读\n";
}

// 检查文件是否可写
if (is_writable("data.txt")) {
    echo "文件可写\n";
}

// 检查是否为文件（不是目录）
if (is_file("data.txt")) {
    echo "这是一个文件\n";
}

// 检查是否为目录
if (is_dir("uploads")) {
    echo "这是一个目录\n";
}
?>