<?php
// 文件打开模式示例

// r 模式：只读，文件必须存在
$file1 = fopen("existing.txt", "r");

// w 模式：只写，清空或创建新文件
$file2 = fopen("newfile.txt", "w");

// a 模式：追加，在末尾写入
$file3 = fopen("log.txt", "a");

fclose($file1);
fclose($file2);
fclose($file3);
?>