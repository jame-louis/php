<?php
// 安全的文件上传函数

function safeUpload($file, $allowedTypes, $maxSize, $uploadDir) {
    // 1. 检查错误码
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => '上传失败'];
    }

    // 2. 检查文件大小
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'message' => '文件太大'];
    }

    // 3. 检查文件类型（MIME）
    if (!in_array($file['type'], $allowedTypes)) {
        return ['success' => false, 'message' => '不允许的文件类型'];
    }

    // 4. 检查扩展名
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowedExts = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($ext, $allowedExts)) {
        return ['success' => false, 'message' => '不允许的扩展名'];
    }

    // 5. 生成安全的文件名
    $newName = date('YmdHis') . '_' . uniqid() . '.' . $ext;
    $destination = $uploadDir . '/' . $newName;

    // 6. 移动文件
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return ['success' => true, 'path' => $destination, 'name' => $newName];
    }

    return ['success' => false, 'message' => '保存失败'];
}

// 使用示例
$result = safeUpload(
    $_FILES['avatar'],
    ['image/jpeg', 'image/png', 'image/gif'],
    2 * 1024 * 1024,
    'uploads'
);

if ($result['success']) {
    echo "上传成功：" . $result['name'];
} else {
    echo "错误：" . $result['message'];
}
?>