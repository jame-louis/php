<?php
// 简便方法 file_get_contents

// 传统方法（需要3步）
$file = fopen("data.txt", "r");
$content = fread($file, filesize("data.txt"));
fclose($file);

// 简便方法（1步搞定）
$content = file_get_contents("data.txt");

// 处理不存在的情况
$content = @file_get_contents("data.txt");
if ($content === false) {
    echo "文件不存在或无法读取";
}
?>