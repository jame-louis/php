<?php
// 查看上传文件信息

print_r($_FILES);

// 输出示例：
// Array (
//     [avatar] => Array (
//         [name] => photo.jpg
//         [type] => image/jpeg
//         [tmp_name] => /tmp/phpXX.tmp
//         [error] => 0
//         [size] => 123456
//     )
// )
?>