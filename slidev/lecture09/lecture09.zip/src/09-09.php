<?php
// 基本文件上传处理

// 检查是否有文件上传
if (!isset($_FILES['avatar'])) {
    die("没有选择文件");
}

$file = $_FILES['avatar'];

// 检查上传是否成功
if ($file['error'] !== UPLOAD_ERR_OK) {
    die("上传失败，错误码：" . $file['error']);
}

// 移动文件到目标位置
$destination = "uploads/" . $file['name'];

if (move_uploaded_file($file['tmp_name'], $destination)) {
    echo "上传成功！文件保存在：{$destination}";
} else {
    echo "移动文件失败";
}
?>