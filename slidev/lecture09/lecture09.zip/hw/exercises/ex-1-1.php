<?php
header('Content-Type: text/html; charset=utf-8');
// 练习：编写一个函数，读取文本文件内容并返回

// 要求：
// 1. 函数名：readFileContent($filename)
// 2. 检查文件是否存在
// 3. 返回文件内容，失败返回false

// 你的代码：




// 测试代码（不要修改）
$content = readFileContent("test.txt");
if ($content !== false) {
    echo "文件内容：" . $content;
} else {
    echo "读取失败";
}
?>