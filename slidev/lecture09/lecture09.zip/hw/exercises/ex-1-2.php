<?php
header('Content-Type: text/html; charset=utf-8');
// 练习：创建访问计数器

// 要求：
// 1. 读取count.txt中的数字
// 2. 数字+1
// 3. 写回文件
// 4. 显示"你是第X位访客"

$filename = "count.txt";

// 你的代码：







// 显示结果
echo "🎉 你是第 {$count} 位访客！";
?>