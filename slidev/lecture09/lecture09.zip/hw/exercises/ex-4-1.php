<?php
header('Content-Type: text/html; charset=utf-8');
// 练习：编写安全的文档上传函数

// 要求：
// 1. 只允许上传doc、docx、pdf文件
// 2. 最大限制5MB
// 3. 文件名使用当前时间+随机数
// 4. 返回包含success、message、path的数组

function uploadDocument($file) {
    // 你的代码：











}

// 测试代码
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = uploadDocument($_FILES['document']);
    print_r($result);
}
?>