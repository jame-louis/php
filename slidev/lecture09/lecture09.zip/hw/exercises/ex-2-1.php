<?php
header('Content-Type: text/html; charset=utf-8');
// 练习：编写函数，统计目录中文件数量

// 要求：
// 1. 函数名：countFiles($directory)
// 2. 返回文件数量（不包括.和..）
// 3. 如果目录不存在返回0

// 你的代码：









// 测试代码
echo "uploads目录有 " . countFiles("uploads") . " 个文件";
?>