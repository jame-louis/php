<?php
header('Content-Type: text/html; charset=utf-8');
// 参考答案：读取文件内容函数

function readFileContent($filename) {
    // 检查文件是否存在
    if (!file_exists($filename)) {
        return false;
    }

    // 打开文件
    $file = fopen($filename, "r");
    if (!$file) {
        return false;
    }

    // 读取内容
    $content = fread($file, filesize($filename));

    // 关闭文件
    fclose($file);

    return $content;
}

// 测试
$content = readFileContent("test.txt");
if ($content !== false) {
    echo $content;
} else {
    echo "读取失败";
}
?>