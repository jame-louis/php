<?php
header('Content-Type: text/html; charset=utf-8');
// 参考答案：统计目录文件数量

function countFiles($directory) {
    // 检查目录是否存在
    if (!is_dir($directory)) {
        return 0;
    }

    // 获取所有文件
    $files = scandir($directory);

    // 计数（排除.和..）
    $count = 0;
    foreach ($files as $file) {
        if ($file != "." && $file != "..") {
            $count++;
        }
    }

    return $count;
}

// 测试
echo "uploads目录有 " . countFiles("uploads") . " 个文件";
?>