<?php
header('Content-Type: text/html; charset=utf-8');
// 参考答案：完整的文件上传处理

// 检查是否有文件上传
if (!isset($_FILES['myfile']) || $_FILES['myfile']['error'] === UPLOAD_ERR_NO_FILE) {
    die("请选择文件");
}

$file = $_FILES['myfile'];

// 检查错误
if ($file['error'] !== UPLOAD_ERR_OK) {
    die("上传失败，错误码：" . $file['error']);
}

// 确保uploads目录存在
if (!is_dir("uploads")) {
    mkdir("uploads");
}

// 移动文件
$destination = "uploads/" . basename($file['name']);

if (move_uploaded_file($file['tmp_name'], $destination)) {
    echo "✅ 上传成功！<br>";
    echo "文件名：" . htmlspecialchars($file['name']) . "<br>";
    echo "文件大小：" . round($file['size'] / 1024, 2) . " KB<br>";
    echo "文件类型：" . $file['type'];
} else {
    echo "❌ 上传失败";
}
?>