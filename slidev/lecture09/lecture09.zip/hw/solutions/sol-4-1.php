<?php
header('Content-Type: text/html; charset=utf-8');
// 参考答案：安全的文档上传函数

function uploadDocument($file) {
    $config = [
        'max_size' => 5 * 1024 * 1024,  // 5MB
        'allowed_exts' => ['doc', 'docx', 'pdf'],
        'allowed_types' => [
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/pdf'
        ],
        'upload_dir' => 'uploads/documents/'
    ];

    // 检查结果
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => '上传失败'];
    }

    // 检查大小
    if ($file['size'] > $config['max_size']) {
        return ['success' => false, 'message' => '文件超过5MB限制'];
    }

    // 检查扩展名
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $config['allowed_exts'])) {
        return ['success' => false, 'message' => '只允许doc、docx、pdf格式'];
    }

    // 创建目录
    if (!is_dir($config['upload_dir'])) {
        mkdir($config['upload_dir'], 0755, true);
    }

    // 生成文件名：20240115_123456_abc123.pdf
    $newName = date('Ymd') . '_' . time() . '_' . uniqid() . '.' . $ext;
    $destination = $config['upload_dir'] . $newName;

    // 移动文件
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return [
            'success' => true,
            'message' => '上传成功',
            'path' => $destination
        ];
    }

    return ['success' => false, 'message' => '保存失败'];
}

// 测试
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = uploadDocument($_FILES['document']);
    print_r($result);
}
?>