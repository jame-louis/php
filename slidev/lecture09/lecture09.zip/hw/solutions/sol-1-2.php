<?php
header('Content-Type: text/html; charset=utf-8');
// 参考答案：访问计数器

$filename = "count.txt";

// 读取当前计数
if (file_exists($filename)) {
    $count = (int)file_get_contents($filename);
} else {
    $count = 0;
}

// 增加计数
$count++;

// 写回文件
file_put_contents($filename, $count);

// 显示结果
echo "🎉 你是第 {$count} 位访客！";
?>